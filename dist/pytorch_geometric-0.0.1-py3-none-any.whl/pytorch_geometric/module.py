def test():
    return 'test'